import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-open-review-dialog',
  templateUrl: './open-review-dialog.component.html',
  styleUrls: ['./open-review-dialog.component.scss']
})
export class OpenReviewDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
