export interface ItemType {
  id: string;
  name: string;
}
