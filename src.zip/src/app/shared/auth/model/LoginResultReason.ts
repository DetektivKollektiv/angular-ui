export enum LoginResultReason {
  LoginSuccessful,
  ConfirmationMissing,
  Cancelled,
}
