export interface SignupResult {
  success: boolean;
}
