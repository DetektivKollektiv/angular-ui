export interface ConfirmResult {
  success: boolean;
}
