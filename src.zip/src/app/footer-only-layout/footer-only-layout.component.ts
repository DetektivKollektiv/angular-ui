import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-only-layout',
  templateUrl: './footer-only-layout.component.html',
  styleUrls: ['./footer-only-layout.component.scss']
})
export class FooterOnlyLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
